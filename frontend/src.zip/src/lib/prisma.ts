// frontend/src/lib/prisma.ts
import { PrismaClient } from '@prisma/client';

const globalForPrisma = global as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ||
  (() => {
    console.log('✨ Nouvelle instance PrismaClient créée');
    return new PrismaClient({
      datasources: { db: { url: process.env.DATABASE_URL } },
    });
  })();

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;

export default prisma;
