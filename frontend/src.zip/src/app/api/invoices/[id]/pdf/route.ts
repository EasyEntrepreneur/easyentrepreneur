// /app/api/invoices/[id]/pdf/route.ts

import { NextResponse } from 'next/server'
import PDFDocument from 'pdfkit'
import prisma from '@/lib/prisma'

export async function GET(req, { params }) {
  const { id } = params
  // Récupère la facture + lignes (et TVA par ligne)
  const invoice = await prisma.invoice.findUnique({
    where: { id },
    include: {
      items: true, // Assure-toi que "items" contient les lignes/prestations avec tauxTVA etc.
      client: true
    }
  })
  if (!invoice) {
    return NextResponse.json({ error: "Facture introuvable" }, { status: 404 })
  }

  // Création PDF
  const doc = new PDFDocument({ margin: 40 })
  const chunks: Buffer[] = []
  doc.on('data', (chunk) => chunks.push(chunk))
  doc.on('end', () => {})

  // HEADER
  doc.fontSize(22).text(`Facture n°${invoice.number}`, { align: 'center' })
  doc.moveDown()
  doc.fontSize(13).text(`Date : ${new Date(invoice.issuedAt).toLocaleDateString("fr-FR")}`)
  doc.text(`Client : ${invoice.client?.name ?? invoice.clientName}`)

  doc.moveDown()

  // TABLEAU DES PRESTATIONS
  doc.fontSize(13).text('Prestations :', { underline: true })
  doc.moveDown(0.5)
  // Table header
  doc.font('Helvetica-Bold').text('Désignation', 50, doc.y, { continued: true })
  doc.text('Qté', 220, doc.y, { width: 40, continued: true, align: 'right' })
  doc.text('PU HT', 270, doc.y, { width: 60, continued: true, align: 'right' })
  doc.text('TVA', 340, doc.y, { width: 40, continued: true, align: 'right' })
  doc.text('Total HT', 400, doc.y, { width: 70, align: 'right' })
  doc.moveDown(0.3)
  doc.font('Helvetica')

  // Lignes
  invoice.items.forEach(item => {
    doc.text(item.label, 50, doc.y, { continued: true })
    doc.text(item.qty.toString(), 220, doc.y, { width: 40, continued: true, align: 'right' })
    doc.text(item.unitPrice.toFixed(2), 270, doc.y, { width: 60, continued: true, align: 'right' })
    doc.text((item.tvaRate ? item.tvaRate + '%' : '0%'), 340, doc.y, { width: 40, continued: true, align: 'right' })
    doc.text((item.qty * item.unitPrice).toFixed(2), 400, doc.y, { width: 70, align: 'right' })
    doc.moveDown(0.2)
  })

  doc.moveDown(1)

  // SOUS-TOTAL & TVA PAR LIGNE
  doc.font('Helvetica-Bold')
  doc.text('Total HT', 340, doc.y, { continued: true })
  doc.text(invoice.totalHT.toFixed(2) + ' €', 400, doc.y, { align: 'right' })
  doc.moveDown(0.2)
  doc.font('Helvetica')

  // Si TVA par ligne, tu peux calculer comme tu veux, exemple (suppose items.tvaRate):
  let totalTVA = 0
  invoice.items.forEach(item => {
    const tva = item.qty * item.unitPrice * (item.tvaRate || 0) / 100
    totalTVA += tva
    doc.text(`TVA ${item.tvaRate || 0}%`, 340, doc.y, { continued: true })
    doc.text(tva.toFixed(2) + ' €', 400, doc.y, { align: 'right' })
    doc.moveDown(0.2)
  })

  doc.font('Helvetica-Bold')
  doc.text('Total TVA', 340, doc.y, { continued: true })
  doc.text(totalTVA.toFixed(2) + ' €', 400, doc.y, { align: 'right' })
  doc.moveDown(0.2)
  doc.text('TOTAL TTC', 340, doc.y, { continued: true })
  doc.text(invoice.totalTTC.toFixed(2) + ' €', 400, doc.y, { align: 'right' })

  doc.moveDown(1.5)
  doc.font('Helvetica').fontSize(10).text('TVA non applicable, art. 293B du CGI.', { align: 'center' })

  doc.end()
  await new Promise((resolve) => doc.on('end', resolve))
  const pdfBuffer = Buffer.concat(chunks)

  return new NextResponse(pdfBuffer, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="Facture-${invoice.number}.pdf"`,
    },
  })
}
